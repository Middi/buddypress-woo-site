<?php

function r_admin_enqueue() {

    wp_register_script( 'adminscripts', plugins_url('/assets/js/admin-global.js', RECIPE_PLUGIN_URL), [], '1.0.0', true );

    wp_enqueue_script( 'adminscripts' );

    if(!isset($_GET['page']) || $_GET['page'] != 'r_plugin_opts') {
        return;
    }

    wp_register_style( 'r_bootstrap', plugins_url('/assets/css/bootstrap.css', RECIPE_PLUGIN_URL));
    wp_enqueue_style('r_bootstrap');
}