<?php

function r_admin_notices() { 

    if(!get_option( 'r_pending_recipe_notice' )) {
        return;
    }
?>

    <div id="r-recipe-pending-notice" class="notice notice-warning is-dismissible">
        <p>You have some recipes waiting to be reviewed.</p>
    </div>

<?php
}