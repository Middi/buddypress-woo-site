# recipe-shortcodes

Simple starter for shortcodes in WP
